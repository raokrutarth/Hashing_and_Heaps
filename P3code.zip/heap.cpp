#include <iostream>
#include <cstdlib>

#include "heap.h"

using namespace std;

    bool TreeNode::operator < (const TreeNode& anotherNode) {
        // TODO : add your logic here.
        return false;
    }
    
    bool TreeNode::operator > (const TreeNode& anotherNode) {
        // TODO : add your logic here.
        return false;
    }
    
    /*
    * If isMaxHeap == true, initialize as a MaxHeap.
    * Else, initialize as a MinHeap.
    */
    BinaryHeap::BinaryHeap(bool isMaxHeap) {
        // TODO : add your logic here.
    }
    
    /*
    * Given an array of TreeNode elements, create the heap.
    * Assume the heap is empty, when this is called.
    */
    void BinaryHeap::heapify(int size, TreeNode * nodes) {
        // TODO : add your logic here.
    }
    
    /*
    * insert the node into the heap.
    * return false, in case of failure.
    * return true for success.
    */
    bool BinaryHeap::insert(TreeNode * node) {
        // TODO : add your logic here.
        return false;
    }
    
    /*
     * Return the minimum element of the min-heap [max element of max-heap]
     */
    TreeNode * BinaryHeap::extract() {
        // TODO : add your logic here.
        return NULL;
    }
    
    /*
     * Return the current size of the Heap.
     */
    int BinaryHeap::size() {
        // TODO : add your logic here.
        return 0;
    }
    
    void heapSort(TreeNode * elements, bool isReverseOrder) {
        // TODO : add your logic here.
    }
