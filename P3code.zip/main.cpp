#include <iostream>
#include <cstdlib>
#include <cstring>

#include "heap.h"

using namespace std;


void CuckooHashing() {
    // TODO : add your logic here.
}

void BinaryHeap() {
    // TODO : add your logic here.
}

void HeapSort() {
    // TODO : add your logic here.
}


/* Main function */
int main(int argc, char** argv) {

    /* Read the option */
    int option;
    std::cin >> option;

    /* Call the respective function */
    switch(option) {

        /* Cuckoo Hashing */
        case 1:
            CuckooHashing();
        break;

        /* Binary Heap */
        case 2:
            BinaryHeap();
        break;
        
        case 3:
            HeapSort();
        break;

        /* Wrong option */
        default:
            std::cout << "Wrong option" << std::endl;

    }

    /* Close the program */
	return 0;
}

